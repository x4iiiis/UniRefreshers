An Example of a Blank Cmake Configured project.
You could pull this whole folder out and keep it in a seperate repo if you wish.
You'll need the physics framework code if you do, grab it from the folder above and edit the CMakeLists.txt(Line 35) to point to it.
You will need to do the same for the sample shaders in the RES folder. (Line 47)
